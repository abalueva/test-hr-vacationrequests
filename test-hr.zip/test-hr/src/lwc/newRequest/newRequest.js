import {LightningElement, track} from 'lwc';

export default class NewRequest extends LightningElement {
    //Boolean tracked variable to indicate if modal is open or not default value is false as modal is closed when page is loaded
    @track isModalOpen = false;
    openModal() {
        this.isModalOpen = true;
    }
    closeModal() {
        this.isModalOpen = false;
    }
    submitDetails() {
        window.location.reload();
    }

    get startDate() {
        var today = new Date();
        return today.toISOString().slice(0,10);
    }


}